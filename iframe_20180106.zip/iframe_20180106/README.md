# webduino-module-text

Webduino Module for Text Displaying.

The module that can display text on panel.

## Installation

```shell
bower install https://github.com/webduinoio/webduino-module-text.git
```

## License

This project is licensed under the MIT license, see [LICENSE](LICENSE) for more information.