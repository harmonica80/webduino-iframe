Blockly.Msg.TEXT_SHOW = "顯示網頁";
Blockly.Msg.URL_SHOW = "網址";
Blockly.Msg.WIDTH_SHOW = "寬度";
Blockly.Msg.HEIGHT_SHOW = "高度";
Blockly.Msg.LEFT_SHOW = "右移距離";
Blockly.Msg.TOP_SHOW = "下移距離";
Blockly.Msg.CLOSE_SHOW = "關閉 顯示網頁";
