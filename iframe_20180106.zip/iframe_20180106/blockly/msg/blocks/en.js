Blockly.Msg.TEXT_SHOW = "Web Page";
Blockly.Msg.URL_SHOW = "url";
Blockly.Msg.WIDTH_SHOW = "width";
Blockly.Msg.LEFT_SHOW = "LEFT";
Blockly.Msg.TOP_SHOW = "TOP";
Blockly.Msg.CLOSE_SHOW = "Close Web Page";
