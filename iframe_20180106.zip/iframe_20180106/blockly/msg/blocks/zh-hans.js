Blockly.Msg.TEXT_SHOW = "显示网页";
Blockly.Msg.URL_SHOW = "网址";
Blockly.Msg.WIDTH_SHOW = "宽度";
Blockly.Msg.HEIGHT_SHOW = "高度";
Blockly.Msg.LEFT_SHOW = "右移距离";
Blockly.Msg.TOP_SHOW = "下移距离";
Blockly.Msg.CLOSE_SHOW = "关闭 显示网页";
